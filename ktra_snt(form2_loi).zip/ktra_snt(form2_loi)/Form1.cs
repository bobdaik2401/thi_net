﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaikiemTra3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool NguyenTo(long n)
        {
            bool nt = true;
             
            // for(int i=2; i< n; i++)
            for (int i = 2; i * i <= n; i++)
                if (n % i == 0)
                {
                    nt = false;
                    break;
                }
            return nt;
        }
        private void btnSoNT_Click(object sender, EventArgs e)
        {
            bool nt = true;
            long n = long.Parse(txtN.Text);
           // for(int i=2; i< n; i++)
            for(int i=2; i*i<=n; i++)
                if (n%i==0)
                {
                    nt = false;
                    break;
                }
            if (nt)
                txtSoNT.Text = n + " là số nguyên tố!";
            else
                txtSoNT.Text = n + " là hợp số!";
        }

        private void btnSoNTN_Click(object sender, EventArgs e)
        {
            txtSoNTN.Text = "";
            long n = long.Parse(txtN.Text);
            for (int i = 2; i <= n; i++)
                if (NguyenTo(i))
                    txtSoNTN.Text = txtSoNTN.Text + i + " , ";
        }

        private void btnSoNT_Sang_Click(object sender, EventArgs e)
        {
            txtSoNTN.Text = "";
            long n = long.Parse(txtN.Text);
            bool[] Sang = new bool[10000];
            for (int i = 0; i < 10000; i++)
                Sang[i] = true;
            Sang[0] = false;
            Sang[1] = false;

            for (int i = 2; i * i <= n; i++)
                if (Sang[i])
                    for (int j = i * i; j <= n; j = j + i)
                        Sang[j] = false;

            for(int i=0; i<= n; i++)
                if (Sang[i])
                    txtSoNTN.Text = txtSoNTN.Text + i + " , ";
        }
    }
}
