﻿namespace BaikiemTra3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.btnSoNT = new System.Windows.Forms.Button();
            this.txtSoNT = new System.Windows.Forms.TextBox();
            this.btnSoNTN = new System.Windows.Forms.Button();
            this.txtSoNTN = new System.Windows.Forms.TextBox();
            this.btnSoNT_Sang = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(128, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nhập số N";
            // 
            // txtN
            // 
            this.txtN.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtN.Location = new System.Drawing.Point(320, 32);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(100, 40);
            this.txtN.TabIndex = 1;
            // 
            // btnSoNT
            // 
            this.btnSoNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoNT.Location = new System.Drawing.Point(102, 109);
            this.btnSoNT.Name = "btnSoNT";
            this.btnSoNT.Size = new System.Drawing.Size(530, 47);
            this.btnSoNT.TabIndex = 2;
            this.btnSoNT.Text = "Kiểm tra số nguyên tố";
            this.btnSoNT.UseVisualStyleBackColor = true;
            this.btnSoNT.Click += new System.EventHandler(this.btnSoNT_Click);
            // 
            // txtSoNT
            // 
            this.txtSoNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNT.Location = new System.Drawing.Point(102, 182);
            this.txtSoNT.Name = "txtSoNT";
            this.txtSoNT.Size = new System.Drawing.Size(530, 40);
            this.txtSoNT.TabIndex = 3;
            // 
            // btnSoNTN
            // 
            this.btnSoNTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoNTN.Location = new System.Drawing.Point(102, 271);
            this.btnSoNTN.Name = "btnSoNTN";
            this.btnSoNTN.Size = new System.Drawing.Size(530, 47);
            this.btnSoNTN.TabIndex = 4;
            this.btnSoNTN.Text = "Tìm các số nguyên tố <N";
            this.btnSoNTN.UseVisualStyleBackColor = true;
            this.btnSoNTN.Click += new System.EventHandler(this.btnSoNTN_Click);
            // 
            // txtSoNTN
            // 
            this.txtSoNTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoNTN.Location = new System.Drawing.Point(102, 424);
            this.txtSoNTN.Name = "txtSoNTN";
            this.txtSoNTN.Size = new System.Drawing.Size(530, 40);
            this.txtSoNTN.TabIndex = 5;
            // 
            // btnSoNT_Sang
            // 
            this.btnSoNT_Sang.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSoNT_Sang.Location = new System.Drawing.Point(102, 343);
            this.btnSoNT_Sang.Name = "btnSoNT_Sang";
            this.btnSoNT_Sang.Size = new System.Drawing.Size(530, 47);
            this.btnSoNT_Sang.TabIndex = 6;
            this.btnSoNT_Sang.Text = "Tìm các số nguyên tố <N  (Sàng NT)";
            this.btnSoNT_Sang.UseVisualStyleBackColor = true;
            this.btnSoNT_Sang.Click += new System.EventHandler(this.btnSoNT_Sang_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 531);
            this.Controls.Add(this.btnSoNT_Sang);
            this.Controls.Add(this.txtSoNTN);
            this.Controls.Add(this.btnSoNTN);
            this.Controls.Add(this.txtSoNT);
            this.Controls.Add(this.btnSoNT);
            this.Controls.Add(this.txtN);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Button btnSoNT;
        private System.Windows.Forms.TextBox txtSoNT;
        private System.Windows.Forms.Button btnSoNTN;
        private System.Windows.Forms.TextBox txtSoNTN;
        private System.Windows.Forms.Button btnSoNT_Sang;
    }
}

