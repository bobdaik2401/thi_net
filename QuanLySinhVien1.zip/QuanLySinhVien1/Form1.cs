﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLySinhVien1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private String DuongDan = " Data Source=LAPTOP-CJJ43TTU;Initial Catalog=SV;Integrated Security=True;";
        
       

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(DuongDan);
            connection.Open();
            SqlDataAdapter ad = new SqlDataAdapter("select * from tbSinhVien ", connection);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dgvSinhVien.DataSource = dt;
            connection.Close();

            dgvSinhVien.Columns[0].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.AllCells;
            dgvSinhVien.Columns[1].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.AllCells;
            dgvSinhVien.Columns[2].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            dgvSinhVien.Columns[0].HeaderText = " MA SV ";
            dgvSinhVien.Columns[1].HeaderText = " Ho va Ten ";
            dgvSinhVien.Columns[2].HeaderText = " Nam Sinh ";


        }

       

        private void btnThem_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(DuongDan);
            con.Open();
            string sql = "insert into tbSinhVien values('" +
                txtMaSinhVien.Text + "', N'" +
                txtTenSinhVien.Text + "', " +
                txtNamSinh.Text + ")";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Đã thêm bản ghi!", "Thông báo");
            //đọc lại dữ liệu
            SqlDataAdapter ad = new SqlDataAdapter("select * from tbSinhVien ", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dgvSinhVien.DataSource = dt;
            con.Close();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string sql = "update tbSinhVien set TenSv=N'" +
               txtTenSinhVien.Text + "', NamSinh = " +
               txtNamSinh.Text + " where MaSV=N'" +
               txtMaSinhVien.Text + "'";
            SqlConnection con = new SqlConnection(DuongDan);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Đã sửa bản ghi!", "Thông báo");
            // đọc lại dữ liệu
            SqlDataAdapter ad = new SqlDataAdapter("select * from tbSinhVien ", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dgvSinhVien.DataSource = dt;
            con.Close();

        }

        private void dgvSinhVien_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSinhVien.CurrentRow != null)
            {
                txtMaSinhVien.Text = dgvSinhVien.CurrentRow.Cells[0].Value.ToString();
                txtTenSinhVien.Text =
                     dgvSinhVien.CurrentRow.Cells[1].Value.ToString();
                txtNamSinh.Text =
                    dgvSinhVien.CurrentRow.Cells[2].Value.ToString();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string sql = "delete tbSinhVien where TenSv ='" + txtTenSinhVien.Text + "'";
            SqlConnection con = new SqlConnection(DuongDan);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Đã xóa bản ghi!", "Thông báo");
            // đọc lại dữ liệu
            SqlDataAdapter ad = new SqlDataAdapter("select * from tbSinhVien ", con);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            dgvSinhVien.DataSource = dt;
            con.Close();
        }

        private void btnDem_Click(object sender, EventArgs e)
        {
            string sql = "select count(*) from tbSinhVien";
            SqlConnection con = new SqlConnection(DuongDan);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            object kq = cmd.ExecuteScalar();
            if (kq == null)
                lbSoSV.Text = " Số SV: 0";
            else
                lbSoSV.Text = "Số SV: " + kq.ToString();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult kq = MessageBox.Show("Bạn muốn đóng chương trình này lại không?",
            "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (kq == DialogResult.Yes)
                this.Close();
        }
    }

    
}
