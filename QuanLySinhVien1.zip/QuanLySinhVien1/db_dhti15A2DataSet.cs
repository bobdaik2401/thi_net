﻿namespace QuanLySinhVien1
{


    public partial class db_dhti15A2DataSet
    {
    }
}
