﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// thêm 2 thư viện này vào
using System.Data;
using System.Data.SqlClient;

namespace BaiKiemTra2
{
   static  class DataAccess
    {
        public static string path =  @"Data Source=.\sqlexpress;Initial Catalog=dboQuanLyCauThu;Integrated Security=True";
        // phương thức tạo kết nối
        private static SqlConnection TaoKetNoi()
        {
            return new SqlConnection(path);
        }

        // Phương thức lấy ra một table/view
        public static DataTable getTable(string sql)
        {
            SqlConnection con = TaoKetNoi();
            con.Open();
            SqlDataAdapter ad = new SqlDataAdapter(sql, con);
            DataTable tb = new DataTable();
            ad.Fill(tb);
            con.Close();
            ad.Dispose();
            return tb;
        }
        // phương thức thêm bản ghi mới
        public static void inSertEditDelete(string sql)
        {
            SqlConnection con = TaoKetNoi();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
            cmd.Dispose();
        }
        // Lấy một giá trị

        public static string getAValule(string sql)
        {
            SqlConnection con = TaoKetNoi();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            object kq = cmd.ExecuteScalar();
            con.Close();
            cmd.Dispose();
            if (kq == null)
                return "";
            else
                return kq.ToString(); 
        }



    }
}
