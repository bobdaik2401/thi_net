﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiKiemTra2
{
    public partial class FormCau2 : Form
    {
        public FormCau2()
        {
            InitializeComponent();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog dl = new FontDialog();
            DialogResult rs = dl.ShowDialog();

            if (rs == DialogResult.OK)
                richTextBox1.Font = dl.Font;
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dl = new ColorDialog();
            DialogResult rs = dl.ShowDialog();

            if (rs == DialogResult.OK)
                richTextBox1.ForeColor = dl.Color;
        }
    }
}
