﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BaiKiemTra2
{
    public partial class FormCau3ThemCT : Form
    {
        public FormCau3ThemCT()
        {
            InitializeComponent();
        }

        private void FormCau3ThemCT_Load(object sender, EventArgs e)
        {

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string sql = "insert into tbCauThu values (N'"+
                txtMaCT.Text+"', N'"+
                txtHoTen.Text+"', N'"+
                txtNgaySinh.Text+"', N'"+
                cbQueQuan.Text+"')";
            DataAccess.inSertEditDelete(sql);
            MessageBox.Show("Đã lưu!");
        }

        private void btnNhapLai_Click(object sender, EventArgs e)
        {
            txtMaCT.Text = "";
            txtHoTen.Text = "";
            txtNgaySinh.Text = "";
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
