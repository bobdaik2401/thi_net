﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Baithithu1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dgvSV.DataSource =
                DataAccess.getTable("select * from SinhVien");

            dgvSV.Columns[0].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.AllCells;
            dgvSV.Columns[1].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.AllCells;
            dgvSV.Columns[2].AutoSizeMode =
               DataGridViewAutoSizeColumnMode.AllCells;
            dgvSV.Columns[3].AutoSizeMode =
              DataGridViewAutoSizeColumnMode.AllCells;
            dgvSV.Columns[4].AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string sql = "insert into SinhVien values ('" +
                 txtMasv.Text + "', N'" +
                 txtHoten.Text + "', N'" +
                 txtNgaysinh.Text + "', N'" +
                 cbKhoa.SelectedItem.ToString() + "', " +
                 txtQuequan.Text + ")";
            DataAccess.insertUpdateDeleteSelect(sql);

            dgvSV.DataSource =
                DataAccess.getTable("select * from SinhVien");
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string sql = "update SinhVien set HoTen=N'" +
             txtHoten.Text + "', NgaySinh =N'" +
             txtNgaysinh.Text + "', Khoa =N'" +
             cbKhoa.SelectedItem.ToString() + "', Que =N'" +
             txtQuequan.Text + "' where MaSinhVien ='" +
             txtMasv.Text + "'";
            DataAccess.insertUpdateDeleteSelect(sql);

            dgvSV.DataSource =
                DataAccess.getTable("select * from SinhVien");
        }

        private void dgvSV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSV.CurrentRow != null)
            {
                txtMasv.Text = dgvSV.CurrentRow.Cells[0].Value.ToString();
                txtHoten.Text = dgvSV.CurrentRow.Cells[1].Value.ToString();
                txtNgaysinh.Text = dgvSV.CurrentRow.Cells[2].Value.ToString();

                // Assuming the "Diachi" column (index 3) holds values that correspond to items in the combobox
                string selectedKhoa = dgvSV.CurrentRow.Cells[3].Value.ToString();
                int selectedIndex = cbKhoa.FindString(selectedKhoa); // Find the corresponding item in the combobox

                // Set the selected item in the combobox (if found)
                if (selectedIndex != -1)
                {
                    cbKhoa.SelectedIndex = selectedIndex;
                }

                txtQuequan.Text = dgvSV.CurrentRow.Cells[4].Value.ToString();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string sql = "delete from SinhVien where MaSinhVien = '" +
             txtMasv.Text + "'";
            DataAccess.insertUpdateDeleteSelect(sql);

            dgvSV.DataSource =
                DataAccess.getTable("select * from SinhVien");
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {

            string searchTerm = txtTimkiem.Text;

            
            if (string.IsNullOrEmpty(searchTerm))
            {
                dgvSV.DataSource = DataAccess.getTable("select * from SinhVien");
                return;
            }

            
            DataTable searchResults = DataAccess.SearchStudents(searchTerm);

            dgvSV.DataSource = searchResults; ;
        }
    }
}
