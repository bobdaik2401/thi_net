﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Baithithu1
{
    internal class DataAccess
    {
        private static string DuongDan = @"Data Source=DESKTOP-VT78S5K\SQLEXPRESS;Initial Catalog=qlsv;Integrated Security=True";
        internal static SqlConnection connection;

        private static SqlConnection creatConnect()
        {
            return new SqlConnection(DuongDan);
        }

        public static DataTable getTable(string sql)
        {
            SqlConnection con = creatConnect();
            con.Open();
            SqlDataAdapter ad = new SqlDataAdapter(sql, con);
            DataTable tb = new DataTable();
            ad.Fill(tb);
            con.Close();
            ad.Dispose();
            return tb;
        }
        public static void insertUpdateDeleteSelect(string sql)
        {
            SqlConnection con = creatConnect();
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
            cmd.Dispose();
        }

        public static DataTable SearchStudents(string searchTerm, string searchField = "MaSinhVien")
        {
            string sql = $"select * from SinhVien where {searchField} = @SearchTerm";

            SqlConnection con = creatConnect();
            con.Open();

            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@SearchTerm", searchTerm);
                DataTable results = new DataTable();
                results.Load(cmd.ExecuteReader());
                return results;
            }
        }
    }
}
