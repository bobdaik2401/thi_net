﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_KT
{
    public partial class Cau2 : Form
    {
        public Cau2()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult kq=MessageBox.Show("Ban co muon thoat khong","Thong bao",MessageBoxButtons.OKCancel,MessageBoxIcon.Question);
            if( kq == DialogResult.OK)
            {
                this.Close();
            }
            else
            {

            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dl = new OpenFileDialog();
            DialogResult rd = dl.ShowDialog();
            if (rd == DialogResult.OK)
            {
                dl.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
  
                File.WriteAllText(dl.FileName, dl.Filter);
                richTextBox1.Text= dl.FileName; 
            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
        
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void Cau2_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
