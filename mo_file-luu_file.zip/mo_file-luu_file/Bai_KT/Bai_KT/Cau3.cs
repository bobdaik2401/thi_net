﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_KT
{
    public partial class Cau3 : Form
    {
        private string sql;
        public Cau3()
        {
            InitializeComponent();
        }
        private void loaddata()
        {
            sql = "Select * from TeamLeader";
            dgv_Teamleader.DataSource=Function.GetData(sql);

        }
        private void dgv_Teamleader_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgv_Teamleader_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if(dgv_Teamleader.CurrentRow != null)
            {
                txt_MA.Text = dgv_Teamleader.CurrentRow.Cells[0].Value.ToString();
                txt_TEN.Text = dgv_Teamleader.CurrentRow.Cells[1].Value.ToString();
                txt_NS.Text = dgv_Teamleader.CurrentRow.Cells[2].Value.ToString();
                txt_ML.Text = dgv_Teamleader.CurrentRow.Cells[3].Value.ToString();
                txt_LTN.Text = dgv_Teamleader.CurrentRow.Cells[4].Value.ToString();
            }
        }

        private void Cau3_Load(object sender, EventArgs e)
        {
            loaddata();
            dgv_Teamleader.Columns[0].HeaderText = "Mã";
            dgv_Teamleader.Columns[1].HeaderText = "Tên";
            dgv_Teamleader.Columns[2].HeaderText = "Năm Sinh";
            dgv_Teamleader.Columns[3].HeaderText = "Mức Lương";
            dgv_Teamleader.Columns[4].HeaderText = "Lương TN";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            sql = "insert into Teamleader values('"+txt_MA.Text+"',N'"+txt_TEN.Text+"',"+txt_NS.Text+","+txt_ML.Text+","+txt_LTN.Text+")";
            Function.ExecuteNonQuery(sql);
            loaddata();
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            sql = "update Teamleader set ten=N'"+txt_TEN.Text+"', namsinh="+txt_NS.Text+",mucLuong="+txt_ML.Text+",LuongTN="+txt_LTN.Text+" where ma='"+txt_MA.Text+"'";
            Function.ExecuteNonQuery(sql);
            loaddata();
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            sql = "delete Teamleader where ma='" + txt_MA.Text + "'";
            Function.ExecuteNonQuery(sql);
            loaddata();
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
