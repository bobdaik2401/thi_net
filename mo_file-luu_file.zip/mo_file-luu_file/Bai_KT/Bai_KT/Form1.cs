﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_KT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void C2_Menu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cau2 cau2 = new Cau2();
            cau2.Show();
        }

        private void C3_Menu_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cau3 cau3 = new Cau3();
            cau3.Show();
        }
    }
}
