﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Bai_KT
{
    internal static class Function
    {
        private static string link="Data Source=doanh;Initial Catalog=qlteamleader;Integrated Security=True";
        private static SqlConnection Connect()
        {
            return new SqlConnection(link);
        }
        public static DataTable GetData(string sql)
        {
            SqlConnection con = Connect();
            con.Open();
            SqlDataAdapter dat = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            dat.Fill(dt);
            con.Close();
            con.Dispose();
            return dt;
        }
        public static void ExecuteNonQuery(string sql)
        {
            SqlConnection conn = Connect();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            conn.Dispose();
        }
    }
}
